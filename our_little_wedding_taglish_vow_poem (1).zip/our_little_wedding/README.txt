OUR LITTLE WEDDING

1. Extract the ZIP file.
2. Keep index.html, coming-up-roses.mp3, and email-template.html together in the same folder.
3. Open index.html in a browser. Music begins after the first invitation click (browser autoplay rules); use the Play/Pause control at the top right.
4. The poem is on the page titled “Wherever You Are” and can be opened from the STORY page or the bottom VOWS navigation button.

WEDDING CEREMONY
The virtual ceremony contains 12 questions. Von chooses one answer for each. At the end, the website sends all selected answers and the final message through EmailJS.

EMAILJS
The website is configured with the EmailJS service, template, and public key provided by the user. To make the email look polished, open the EmailJS template, switch its Content editor to the HTML/code editor, and paste the complete contents of email-template.html. Set:
- To Email: punlaallyson@gmail.com
- Subject: Our Little Wedding — Von's Answers ♡
- From Name: Our Little Wedding
- Reply To: punlaallyson@gmail.com
The HTML template uses exactly these variables: {{von_answers}}, {{final_message}}, and {{wedding_date}}.

The website sends the email automatically at the end of the 12 questions and also keeps a retry button on the final page if sending fails. Email delivery still depends on the EmailJS service being active and the website origin being allowed in EmailJS settings. The website code has not been able to verify actual inbox delivery from this environment.

This is a virtual keepsake ceremony, not a legal marriage document.
